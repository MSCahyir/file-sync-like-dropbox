function showTravelVariants(departureCity, destinationCity, travelDate, travelDateReturn) {
  let apiUrl = "https://api.gunsel.ua/Public.svc/GetTravelVariantListWithContent?1=1&";
  if (departureCity != "")
    apiUrl += "c0=" + departureCity + "&";
  if (destinationCity != "")
    apiUrl += "c1=" + destinationCity + "&";
  if (travelDate != "")
    apiUrl += "c2=" + travelDate + "&";
  if (travelDateReturn != "")
    apiUrl += "c3=" + travelDateReturn + "&";

  apiUrl += "c4=true";

  const xhr = new XMLHttpRequest();
  var strResponse = "";
  var currentUrl = window.location.href;
  currentUrl += '/response?'
  if (departureCity != "")
    currentUrl += "c0=" + departureCity + "&";
  if (destinationCity != "")
    currentUrl += "c1=" + destinationCity + "&";
  // travelDate = formatDate(travelDate);
  currentUrl += "c2=" + travelDate + "&";
  currentUrl += "c3=" + travelDateReturn + "&";
  currentUrl += "c4=true";
  window.location.href = currentUrl;
}

function openUrlWithDate(city) {
  const currentDate = new Date();
  const year = currentDate.getFullYear();
  const month = String(currentDate.getMonth() + 1).padStart(2, '0'); // Ayı alırken +1 eklemeyi unutmayın, çünkü aylar 0'dan başlar.
  const day = String(currentDate.getDate()).padStart(2, '0');
  const dateString = `${day}/${month}/${year}`;
  dateString = formatDate(dateString);
  let departureCity = ""
  city = getStationId(city);
  showTravelVariants(departureCity, destinationCity, dateString);
}


function openUrlWithDateAndCity(citySource, cityDest) {
  const currentDate = new Date();
  const year = currentDate.getFullYear();
  const month = String(currentDate.getMonth() + 1).padStart(2, '0'); // Ayı alırken +1 eklemeyi unutmayın, çünkü aylar 0'dan başlar.
  let day = String(currentDate.getDate()).padStart(2, '0');
  let dateString = `${day}/${month}/${year}`;
  dateString = formatDate(dateString);

  console.log(dateString);

  citySource = getStationId(citySource);
  cityDest = getStationId(cityDest);

  showTravelVariants(citySource, cityDest, dateString, "");
}

// function getCityCode(cityName) {
//     switch (cityName) {
//         case "İstanbul":
//             return "7c8324d6-69e7-4b5f-bbe9-ecae20c68bc3";
//         case "Kiev":
//             return "b35dfead-640e-403a-b252-cb4af06a8ac4";
//         case "Antalya":
//             return "9e5b1edd-f90a-489e-9e52-0a132795bada";
//         default:
//             return "";
//     }
// }


function formatDate(inputDate) {
  let dateParts = inputDate.split("/");
  let year = dateParts[2];
  let month = dateParts[0].padStart(2, "0");
  let day = dateParts[1].padStart(2, "0");
  return year + "-" + month + "-" + day;
}

function getStationId(stationName) {
  const array = [
    { StationId: 'b35dfead-640e-403a-b252-cb4af06a8ac4', StationName: 'Kyiv' },
    { StationId: '7c8324d6-69e7-4b5f-bbe9-ecae20c68bc3', StationName: 'Istanbul' },
    { StationId: '08d6640d-0cba-4c47-8f3a-374705cf0f5f', StationName: 'Bucharest' },
    { StationId: '4b239e5f-95d7-4c49-aa5e-319fc7d03a00', StationName: 'Warsaw (Zachodnia)' },
    { StationId: '56f268a1-4863-4b82-b4bf-6b234430de33', StationName: 'Vinnytsia' },
    { StationId: '1dc5f9d3-d159-4dd9-b573-8415736acf36', StationName: 'Zhytomyr' },
    { StationId: '0ed294ae-cd0c-448f-b5c5-b65b98c7017f', StationName: 'Ivano-Frankivsk' },
    { StationId: '329c573e-179b-433d-ad08-2656768fd17c', StationName: 'Lviv' },
    { StationId: '6f9ff261-937a-4835-882b-fcc2ec33db10', StationName: 'Mykolaiv' },
    { StationId: '69a281f8-437d-4f55-bb8a-156b3820f20a', StationName: 'Odessa' },
    { StationId: '4ccf5c1b-8ca6-4ef2-97cc-65caf402634e', StationName: 'Khmelnitsky' },
    { StationId: '2230fce3-df37-4108-8695-f96ed9c84ba1', StationName: 'Chernivtsi' },
    { StationId: 'a8b4e664-7308-4194-ad5b-804282e0c6e3', StationName: 'Chernivtsi' },
    { StationId: '9e5b1edd-f90a-489e-9e52-0a132795bada', StationName: 'Antalya' },
    { StationId: 'cccfdce2-da42-4d72-b5ca-542416f8f63d', StationName: 'Bacau' },
    { StationId: '796bcc8b-f979-4d95-9e11-7cdbb63223ef', StationName: 'Bila Tserkva' },
    { StationId: '585cb1f0-1f45-45c2-bfef-5ad8603bb330', StationName: 'Blahovishchenske' },
    { StationId: '2b97224a-5a85-4fae-9f14-b495d3abefbc', StationName: 'Bucharest' },
    // Add more station objects as needed
  ];

  const station = array.find((item) => item.StationName === stationName);
  return station ? station.StationId : null;
}



const stationData = [
  {
    StationId: 'b35dfead-640e-403a-b252-cb4af06a8ac4',
    StationName: 'Kyiv'
  },
  {
    StationId: '7c8324d6-69e7-4b5f-bbe9-ecae20c68bc3',
    StationName: 'Istanbul'
  },
  {
    StationId: '08d6640d-0cba-4c47-8f3a-374705cf0f5f',
    StationName: 'Bucharest'
  },
  {
    StationId: '4b239e5f-95d7-4c49-aa5e-319fc7d03a00',
    StationName: 'Warsaw (Zachodnia)'
  },
  {
    StationId: '56f268a1-4863-4b82-b4bf-6b234430de33',
    StationName: 'Vinnytsia'
  },
  {
    StationId: '1dc5f9d3-d159-4dd9-b573-8415736acf36',
    StationName: 'Zhytomyr'
  },
  {
    StationId: '0ed294ae-cd0c-448f-b5c5-b65b98c7017f',
    StationName: 'Ivano-Frankivsk'
  },
  {
    StationId: '329c573e-179b-433d-ad08-2656768fd17c',
    StationName: 'Lviv'
  },
  {
    StationId: '6f9ff261-937a-4835-882b-fcc2ec33db10',
    StationName: 'Mykolaiv'
  },
  {
    StationId: '69a281f8-437d-4f55-bb8a-156b3820f20a',
    StationName: 'Odessa'
  },
  {
    StationId: '4ccf5c1b-8ca6-4ef2-97cc-65caf402634e',
    StationName: 'Khmelnitsky'
  },
  {
    StationId: '2230fce3-df37-4108-8695-f96ed9c84ba1',
    StationName: 'Chernivtsi'
  },
  {
    StationId: 'a8b4e664-7308-4194-ad5b-804282e0c6e3',
    StationName: 'Chernivtsi'
  },
  {
    StationId: '9e5b1edd-f90a-489e-9e52-0a132795bada',
    StationName: 'Antalya'
  },
  {
    StationId: 'cccfdce2-da42-4d72-b5ca-542416f8f63d',
    StationName: 'Bacau'
  },
  {
    StationId: '796bcc8b-f979-4d95-9e11-7cdbb63223ef',
    StationName: 'Bila Tserkva'
  },
  {
    StationId: '585cb1f0-1f45-45c2-bfef-5ad8603bb330',
    StationName: 'Blahovishchenske'
  },
  {
    StationId: '2b97224a-5a85-4fae-9f14-b495d3abefbc',
    StationName: 'Bucharest'
  },
  {
    StationId: '4f2601fe-00b5-4a9c-a3ba-6287d173b1d5',
    StationName: 'Burgas'
  },
  {
    StationId: 'a9a76898-4163-4279-b20e-f8592e222167',
    StationName: 'Constanta'
  },
  {
    StationId: '1fa0ddf0-529f-4729-8711-1e9c3f36230a',
    StationName: 'Dnipro'
  },
  {
    StationId: '68e86686-a257-4cb0-ae92-ce0c886ff7b7',
    StationName: 'Focsani'
  },
  {
    StationId: 'bff6fd6a-a795-47bc-a903-1a15f998b9b4',
    StationName: 'Istanbul (IST Airport)'
  },
  {
    StationId: '0e40cf8e-6d2b-4dcd-8fcf-a44349515466',
    StationName: 'Kamianets-Podilskyi'
  },
  {
    StationId: 'ad3395e1-5f96-4bdc-97a9-90609d232b8c',
    StationName: 'Kherson'
  },
  {
    StationId: '880c3b8b-596f-4c1e-ba7b-21e7f7e94bab',
    StationName: 'Kovel'
  },
  {
    StationId: 'e0bdfe66-c648-447a-b20b-82415833419a',
    StationName: 'Kryve Ozero'
  },
  {
    StationId: '964889ec-709e-4cda-bc9f-80e005c9f0c9',
    StationName: 'Kryvyi Rih'
  },
  {
    StationId: 'cc11542a-07ff-48ba-b0ca-bf9fceb75372',
    StationName: 'Kyiv'
  },
  {
    StationId: 'ff3f38d4-781c-430c-bd35-99ed2b000387',
    StationName: 'Kyiv (Zhytomyrska)'
  },
  {
    StationId: 'fb29f566-9c64-4223-8b8f-4d7b57686d54',
    StationName: 'Liubashivka'
  },
  {
    StationId: 'fe3c0db6-c2f1-4357-86a2-54fba89ae9a6',
    StationName: 'Lublin'
  },
  {
    StationId: 'dd9fe7dd-398f-4a8f-ba02-2a1ec5b78889',
    StationName: 'Lutsk'
  },
  {
    StationId: '247b8b2b-f7db-4c1c-a446-a3474d14bade',
    StationName: 'Nova Odesa'
  },
  {
    StationId: '7bea225d-4fa5-4059-aef5-5955a774b866',
    StationName: 'Pervomaisk'
  },
  {
    StationId: '5e2329ea-d278-4a48-a292-9e9307d22b11',
    StationName: 'Praha (Praha hl.n.)'
  },
  {
    StationId: 'c5e1c914-18fd-44b5-973a-d9a05ca2b020',
    StationName: 'Rivne'
  },
  {
    StationId: '0f0a3123-0ee8-4d8f-9a6d-8e9f7e0a1ebf',
    StationName: 'Sumy'
  },
  {
    StationId: '9e4da5f1-8a13-4b6c-aef9-fa33f4e7280d',
    StationName: 'Ternopil'
  },
  {
    StationId: '2c4e59e1-44b5-4319-bd8d-6ea2de43ef8a',
    StationName: 'Uman'
  },
  {
    StationId: 'a6c9be94-8b66-47ef-a835-3ce79895dfeb',
    StationName: 'Vinnytsia'
  },
  {
    StationId: '6dc11014-8c0e-421d-86a4-d11bc29944ff',
    StationName: 'Volovets'
  },
  {
    StationId: '22d33e41-c1db-4b6d-af4f-7dc2d99696c2',
    StationName: 'Zaliznyi Port'
  },
  {
    StationId: 'a2b15fd4-4004-49d7-9653-c30bc24023ac',
    StationName: 'Zaporizhzhia'
  },
  {
    StationId: 'f2f84a8d-f8fa-4141-9801-09447b883c8b',
    StationName: 'Zhytomyr'
  },
  {
    StationId: 'da59ed3d-66fa-4706-a4be-4aafb47b3e24',
    StationName: 'Zielona Gora'
  },
  {
    StationId: '57fc97cc-b7b9-4072-9e68-bf0e7e4a94f2',
    StationName: 'Zhovti Vody'
  },
  {
    StationId: 'a9c9c747-5c7a-43d7-b6e5-df38f591c8be',
    StationName: 'Iasi'
  },
  {
    StationId: 'a7a460f4-6b10-47b4-8227-7e7911806b8c',
    StationName: 'Chisinau'
  }
];



function getStationId(stationName) {
  // Find the station object with the matching name
  const station = stationData.find(station => station.StationName.toLowerCase() === stationName.toLowerCase());

  // If a matching station is found, return its ID
  if (station) {
    return station.StationId;
  }

  // If no matching station is found, return null or any other appropriate value
  return null;
}